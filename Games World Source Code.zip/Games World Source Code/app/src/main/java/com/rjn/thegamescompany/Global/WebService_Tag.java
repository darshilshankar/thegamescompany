package com.rjn.thegamescompany.Global;

public class WebService_Tag {

    public static String MAIN_URL = "http://axoapp.axoneinfotech.com/AdminLTE/";
    //public static String MAIN_URL = "http://gcoadmin.ligerinfotech.com/";

    public static String M_API_all_app = MAIN_URL + "API_all_app.php";
    public static String M_API_dashboard_list = MAIN_URL + "API_dashboard_list.php";
    public static String M_API_fetch_app_by_cate_pub = MAIN_URL + "API_fetch_app_by_cate_pub.php";
    public static String M_API_all_cate_pub = MAIN_URL + "API_all_cate_pub.php";
    public static String M_API_counter = MAIN_URL + "API_counter.php";
    public static String M_API_tranding_app_counter_wise = MAIN_URL + "API_tranding_app_counter_wise.php";
    public static String M_API_get_application_details = MAIN_URL + "API_get_application_details.php";
    public static String M_API_version = MAIN_URL + "API_version.php";

    public static String R_id = "id";
    public static String R_name = "name";
    public static String R_cate_id = "cate_id";
    public static String R_icon = "icon";
    public static String R_email = "email";
    public static String R_pub_id = "pub_id";
    public static String R_app_id = "app_id";
    public static String R_html_flash = "html_flash";
    public static String R_url = "url";
    public static String R_counter = "counter";
    public static String R_position_order = "position_order";
    public static String R_pname = "pname";
    public static String R_cname = "cname";
    public static String R_image = "image";
    public static String R_category = "category";
    public static String R_publisher = "publisher";
    public static String R_banner = "banner";
    public static String R_app_last_ten = "app_last_ten";
    public static String R_app_trad_ten = "app_trad_ten";
    public static String R_app_cate = "app_cate";

    public static String R_app_count = "app_count";
    public static String R_total_app = "total_app";
}
